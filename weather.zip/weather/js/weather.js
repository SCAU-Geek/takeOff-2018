function getToday(){
  $.ajax({
    type:'GET',
    url:"https://free-api.heweather.com/s6/weather/forecast?location=CN101280101&key=6e4d42c90348497b8191a7254ef0753e",
    async:"false",
    success:function(msg){
      console.log(msg.HeWeather6[0]);
      var table ="<table><tr> <th>日期</th> <th>天气</th> <th>温度</th> <th>风力</th> </tr>"
      for(var i = 0; i<msg.HeWeather6[0].daily_forecast.length; i++){
        table += '<tr><td>' +msg.HeWeather6[0].daily_forecast[i].date +'</td>';
        table += '<td>'+ msg.HeWeather6[0].daily_forecast[i].cond_txt_d +'</td>';
        table += '<td>'+ msg.HeWeather6[0].daily_forecast[i].tmp_min+"~"+msg.HeWeather6[0].daily_forecast[i].tmp_max +'</td>';
        table += '<td>'+ msg.HeWeather6[0].daily_forecast[i].wind_sc +'</td></tr>';
      }
      table+='</table>';
      $('#today').html(table);
      var aver = (Number(msg.HeWeather6[0].daily_forecast[0].tmp_min)+Number(msg.HeWeather6[0].daily_forecast[0].tmp_max))/2.0;
      $('#info').html(`
        <h3>${msg.HeWeather6[0].basic.location}</h3>
        <h1>${aver}℃</h1>
        <h3>白天：${msg.HeWeather6[0].daily_forecast[0].cond_txt_d} 夜晚：${msg.HeWeather6[0].daily_forecast[0].cond_txt_n}</h3>
        <
        `);
    },
    error:function(err){
      console.log(err);
    }
  });
}

getToday();
