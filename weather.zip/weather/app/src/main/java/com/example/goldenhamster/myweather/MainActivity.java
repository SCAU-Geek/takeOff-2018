package com.example.goldenhamster.myweather;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.hdl.myhttputils.MyHttpUtils;
import com.hdl.myhttputils.bean.CommCallback;
import com.hdl.myhttputils.utils.FailedMsgUtils;

public class MainActivity extends AppCompatActivity {
    private String city = "广州";
    private TextView tmp;
    private TextView location;
    private TextView condTxt;
    private TextView condTxt1;
    private TextView windDir1;
    private TextView tmpMax1;
    private TextView tmpMin1;
    private TextView condTxt2;
    private TextView windDir2;
    private TextView tmpMax2;
    private TextView tmpMin2;
    private TextView condTxt3;
    private TextView windDir3;
    private TextView tmpMax3;
    private TextView tmpMin3;
    private TextView dress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        requestData();
    }
    private void initView(){
        tmp = findViewById(R.id.tmp);
        location = findViewById(R.id.location);
        condTxt = findViewById(R.id.cond_txt);
        condTxt1 = findViewById(R.id.cond_txt_1);
        windDir1 = findViewById(R.id.wind_dir_1);
        tmpMax1 = findViewById(R.id.tmp_max_1);
        tmpMin1 = findViewById(R.id.tmp_min_1);
        condTxt2 = findViewById(R.id.cond_txt_2);
        windDir2 = findViewById(R.id.wind_dir_2);
        tmpMax2 = findViewById(R.id.tmp_max_2);
        tmpMin2 = findViewById(R.id.tmp_min_2);
        condTxt3 = findViewById(R.id.cond_txt_3);
        windDir3 = findViewById(R.id.wind_dir_3);
        tmpMax3 = findViewById(R.id.tmp_max_3);
        tmpMin3 = findViewById(R.id.tmp_min_3);
        dress = findViewById(R.id.dress);
    }
    private void setWeather(WeatherBean nb){
        tmp.setText(nb.getHeWeather6().get(0).getNow().getTmp());
        location.setText(nb.getHeWeather6().get(0).getBasic().getLocation());
        condTxt.setText(nb.getHeWeather6().get(0).getNow().getCond_txt());
        condTxt1.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(0).getCond_txt_d());
        windDir1.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(0).getWind_dir());
        tmpMax1.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(0).getTmp_max() + "/");
        tmpMin1.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(0).getTmp_min() + "度");
        condTxt2.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(1).getCond_txt_d());
        windDir2.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(1).getWind_dir());
        tmpMax2.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(1).getTmp_max() + "/");
        tmpMin2.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(1).getTmp_min() + "度");
        condTxt3.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(2).getCond_txt_d());
        windDir3.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(2).getWind_dir());
        tmpMax3.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(2).getTmp_max() + "/");
        tmpMin3.setText(nb.getHeWeather6().get(0).getDaily_forecast().get(2).getTmp_min() + "度");
        dress.setText(nb.getHeWeather6().get(0).getLifestyle().get(1).getTxt());
    }
    private void requestData(){
        MyHttpUtils.build()
                .url("https://free-api.heweather.com/s6/weather")
                .addParam("location", city )
                .addParam("key", "b297c165e2ad4e3780602cb671f0ddbb")
                .setJavaBean(WeatherBean.class)
                .onExecute(new CommCallback<WeatherBean>() {
                    @Override
                    public void onSucceed(WeatherBean weatherBean) {
                        setWeather(weatherBean);
                    }

                    @Override
                    public void onFailed(Throwable throwable) {
                        Toast.makeText(MainActivity.this, FailedMsgUtils.getErrMsgStr(throwable),Toast.LENGTH_LONG ).show();
                    }
                });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_activity, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.refresh:
                requestData();
                break;
            case R.id.guangzhou:
                city = "广州";
                requestData();
                break;
            case R.id.beijing:
                city = "北京";
                requestData();
                break;
            case R.id.haerbin:
                city = "哈尔滨";
                requestData();
                break;
            case R.id.wulumuqi:
                city = "乌鲁木齐";
                requestData();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
